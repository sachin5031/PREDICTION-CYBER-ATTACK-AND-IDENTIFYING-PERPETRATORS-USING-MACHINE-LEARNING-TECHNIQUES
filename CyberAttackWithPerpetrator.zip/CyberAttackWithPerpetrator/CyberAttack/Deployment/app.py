import numpy as np
from flask import Flask, request, jsonify, render_template
import joblib

app = Flask(__name__)
model1 = joblib.load('Attack.pkl')
model2 = joblib.load('Perpetrator.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict',methods=['POST'])
def predict():
    int_features = [(x) for x in request.form.values()]
    final_features = int_features[0:9]
    final_features = [np.array(final_features)]
    predictionC = model1.predict(final_features)
    output = str(predictionC[0])
    
    if output == '0':
        a = 'Card Copying / Generating Devices'
    elif output == '1':
        a = 'Creating a Fake Shopping Site'
    elif output == '2':
        a = 'Hacking Tools or Malware'
    elif output == '3':
        a = 'Phishing Attack'
    elif output == '4':
        a = 'Receiving Public Data on Social Media'
    elif output == '5':
        a = 'Social Engineering'
        
    int_features.append(output)
    final_featuresY = [np.array(int_features)]
    predictionY = model2.predict(final_featuresY)
    outputY = predictionY[0]
    if outputY==0:
        outputY='Known'
    else:
        outputY="UnKnown"

    return render_template('index.html', prediction_text1=f"Attack Method is {a}", prediction_text2=f"Perpetrator is {outputY}")


if __name__ == "__main__":
    app.run(host="localhost", port=5005)
