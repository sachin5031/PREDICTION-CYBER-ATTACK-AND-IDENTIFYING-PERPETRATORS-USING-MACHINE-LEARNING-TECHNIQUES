# CyberAttackWithPerpetrator
scikit-learn==1.0.2
imbalanced-learn==0.8.1
matplotlib==3.5.2
seaborn==0.11.2
flask==1.1.2
pandas==1.4.4
